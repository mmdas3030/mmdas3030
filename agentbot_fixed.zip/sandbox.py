"""
اجرای کد پایتون در یک پردازه‌ی جدا (subprocess) با محدودیت زمان و منابع.

⚠️ توجه امنیتی مهم:
این sandbox یک محدودسازی سطح-پردازه است (timeout + resource limits)،
نه یک ایزوله‌سازی کامل مثل کانتینر Docker. یعنی کد اجراشده هنوز روی
همون ماشینی که ربات روشه اجرا می‌شه (با کاربر لینوکسی محدودتر در صورت امکان).
برای امنیت بیشتر در پروداکشن واقعی (مثل سرویس عمومی با کاربران ناشناس)
پیشنهاد می‌شه یک لایه‌ی اضافه مثل nsjail، firejail یا اجرای داخل یک
کانتینر Docker یک‌بارمصرف جدا اضافه بشه. برای یک ربات سرور شخصی/دوستانه
این سطح از محدودیت معمولاً کافیه.
"""
import asyncio
import os
import resource
import subprocess
import sys
import tempfile
import textwrap

import config

# ماژول‌هایی که اجازه‌ی import ندارن (لایه‌ی دوم دفاعی، نه تنها راه دفاع)
BLOCKED_IMPORTS = {
    "os.system", "subprocess", "shutil.rmtree", "socket",
    "ctypes", "multiprocessing", "importlib",
}

BLOCKED_KEYWORDS = ["__import__", "eval(", "exec(", "open(", "os.remove", "os.unlink"]


def _pre_check(code: str) -> str | None:
    """چک سطحی برای جلوگیری از بدیهی‌ترین سوءاستفاده‌ها. خروجی: پیام خطا یا None."""
    for kw in BLOCKED_KEYWORDS:
        if kw in code:
            return f"استفاده از «{kw}» در sandbox مجاز نیست."
    return None


def _limit_resources():
    """در پردازه‌ی فرزند اجرا می‌شه؛ محدودیت CPU و حافظه رو تنظیم می‌کنه."""
    try:
        resource.setrlimit(resource.RLIMIT_CPU, (config.SANDBOX_TIMEOUT_SECONDS, config.SANDBOX_TIMEOUT_SECONDS))
        mem_bytes = 256 * 1024 * 1024  # 256MB
        resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
        resource.setrlimit(resource.RLIMIT_NPROC, (32, 32))
        resource.setrlimit(resource.RLIMIT_FSIZE, (1024 * 1024, 1024 * 1024))  # 1MB فایل
    except Exception:
        pass  # روی بعضی سیستم‌عامل‌ها (مثل ویندوز) resource وجود نداره


async def run_python(code: str) -> tuple[bool, str]:
    """
    کد پایتون رو اجرا می‌کنه. خروجی: (موفقیت‌آمیز؟, متن خروجی/خطا)
    """
    err = _pre_check(code)
    if err:
        return False, err

    wrapped = textwrap.dedent(code)

    with tempfile.TemporaryDirectory() as tmpdir:
        script_path = os.path.join(tmpdir, "snippet.py")
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(wrapped)

        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-I", "-S", script_path,  # -I: isolated mode, -S: no site
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=tmpdir,
                preexec_fn=_limit_resources if os.name != "nt" else None,
            )
            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(), timeout=config.SANDBOX_TIMEOUT_SECONDS + 2
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                return False, f"اجرا بیش از {config.SANDBOX_TIMEOUT_SECONDS} ثانیه طول کشید و متوقف شد."

            out = stdout.decode(errors="replace")
            errtxt = stderr.decode(errors="replace")

            combined = out
            if errtxt:
                combined += ("\n" if combined else "") + f"[stderr]\n{errtxt}"

            if len(combined) > config.SANDBOX_MAX_OUTPUT_CHARS:
                combined = combined[: config.SANDBOX_MAX_OUTPUT_CHARS] + "\n... (بریده شد)"

            ok = proc.returncode == 0
            if not combined.strip():
                combined = "(خروجی‌ای تولید نشد)" if ok else "کد با خطا متوقف شد."
            return ok, combined
        except Exception as e:
            return False, f"خطای داخلی در اجرای sandbox: {e}"
