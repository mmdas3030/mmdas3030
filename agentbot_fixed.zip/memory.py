"""
حافظه‌ی مکالمه، دائمی و بر اساس هر کانال دیسکورد (channel_id).
از aiosqlite استفاده می‌کنیم که async-friendly هست و event loop رو بلاک نمی‌کنه.

علاوه بر پیام‌های خام، وقتی تاریخچه‌ی یک کانال خیلی طولانی بشه، پیام‌های
قدیمی‌تر به‌صورت خودکار توسط یک مدل ارزون خلاصه می‌شن (memory.maybe_summarize)
تا context همیشه smart-کوتاه بمونه ولی چیزی از یاد نره.
"""
import os
import time
import aiosqlite
import config

MAX_TURNS_PER_CHANNEL = 12  # تعداد پیام‌های خامی که همیشه کامل نگه می‌داریم

# اگه تعداد کل پیام‌های یک کانال از این عدد بیشتر شد، قدیمی‌ترها خلاصه می‌شن
SUMMARY_TRIGGER_MESSAGES = 16
# بعد از خلاصه‌سازی، این تعداد پیام آخر همچنان خام نگه داشته می‌شه
SUMMARY_KEEP_RECENT = 12

# طول هر پیام موقع خوندن از دیتابیس (برای فرستادن به مدل) به این تعداد کاراکتر
# محدود می‌شه؛ خودِ رکورد کامل توی دیتابیس دست‌نخورده می‌مونه، فقط چیزی که به
# API فرستاده می‌شه کوتاه می‌شه. این جلوی context_length_exceeded رو می‌گیره
# وقتی یه پیام قبلی (مثلاً کد ۳۰۰ خطی) خیلی بزرگ بوده.
MAX_MESSAGE_CHARS_FOR_CONTEXT = 3000

_SCHEMA = """
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id INTEGER NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_channel ON messages(channel_id);

CREATE TABLE IF NOT EXISTS preferences (
    channel_id INTEGER PRIMARY KEY,
    model_key TEXT NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS summaries (
    channel_id INTEGER PRIMARY KEY,
    summary TEXT NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id INTEGER PRIMARY KEY,
    ai_channel_id INTEGER,
    threads_enabled INTEGER NOT NULL DEFAULT 1,
    updated_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS ai_threads (
    thread_id INTEGER PRIMARY KEY,
    owner_id INTEGER NOT NULL,
    created_at REAL NOT NULL
);
"""


async def init_db():
    # پوشه‌ی data ممکنه روی هاست جدید وجود نداشته باشه؛ خودمون می‌سازیمش
    os.makedirs(os.path.dirname(config.DB_PATH), exist_ok=True)
    async with aiosqlite.connect(config.DB_PATH) as db:
        await db.executescript(_SCHEMA)
        await db.commit()


async def add_message(channel_id: int, role: str, content: str):
    async with aiosqlite.connect(config.DB_PATH) as db:
        await db.execute(
            "INSERT INTO messages (channel_id, role, content, created_at) VALUES (?, ?, ?, ?)",
            (channel_id, role, content, time.time()),
        )
        await db.commit()


async def get_history(channel_id: int, limit: int = MAX_TURNS_PER_CHANNEL) -> list[dict]:
    async with aiosqlite.connect(config.DB_PATH) as db:
        cursor = await db.execute(
            "SELECT role, content FROM messages WHERE channel_id = ? "
            "ORDER BY id DESC LIMIT ?",
            (channel_id, limit),
        )
        rows = await cursor.fetchall()

        summary_cursor = await db.execute(
            "SELECT summary FROM summaries WHERE channel_id = ?", (channel_id,)
        )
        summary_row = await summary_cursor.fetchone()

    rows.reverse()
    history = []
    for r, c in rows:
        if len(c) > MAX_MESSAGE_CHARS_FOR_CONTEXT:
            c = (
                c[:MAX_MESSAGE_CHARS_FOR_CONTEXT]
                + f"\n...[متن بریده شد، {len(c)} کاراکتر بود؛ نسخه‌ی کامل توی فایل ارسالی موجوده]"
            )
        history.append({"role": r, "content": c})

    if summary_row and summary_row[0]:
        history = [{
            "role": "system",
            "content": f"خلاصه‌ی مکالمه‌های قبلی‌ترِ این کانال (برای حفظ context):\n{summary_row[0]}",
        }] + history

    return history


async def search_history(channel_id: int, keyword: str, limit: int = 10) -> list[dict]:
    """جست‌وجوی ساده‌ی متنی توی تاریخچه‌ی خام یک کانال؛ برای ابزار search_memory در agent.py."""
    async with aiosqlite.connect(config.DB_PATH) as db:
        cursor = await db.execute(
            "SELECT role, content, created_at FROM messages "
            "WHERE channel_id = ? AND content LIKE ? ORDER BY id DESC LIMIT ?",
            (channel_id, f"%{keyword}%", limit),
        )
        rows = await cursor.fetchall()
    rows.reverse()
    return [{"role": r, "content": c, "created_at": t} for r, c, t in rows]


async def clear_history(channel_id: int):
    async with aiosqlite.connect(config.DB_PATH) as db:
        await db.execute("DELETE FROM messages WHERE channel_id = ?", (channel_id,))
        await db.commit()


async def set_model_preference(channel_id: int, model_key: str):
    """مدلی که کاربر برای این کانال انتخاب کرده رو ذخیره می‌کنه (upsert)."""
    async with aiosqlite.connect(config.DB_PATH) as db:
        await db.execute(
            "INSERT INTO preferences (channel_id, model_key, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(channel_id) DO UPDATE SET model_key = excluded.model_key, "
            "updated_at = excluded.updated_at",
            (channel_id, model_key, time.time()),
        )
        await db.commit()


async def get_model_preference(channel_id: int) -> str | None:
    """مدل انتخابیِ کاربر رو برمی‌گردونه، یا None اگه چیزی تنظیم نشده (یعنی auto)."""
    async with aiosqlite.connect(config.DB_PATH) as db:
        cursor = await db.execute(
            "SELECT model_key FROM preferences WHERE channel_id = ?", (channel_id,)
        )
        row = await cursor.fetchone()
    if row and row[0] and row[0] != "auto":
        return row[0]
    return None


async def maybe_summarize(channel_id: int):
    """
    اگه تعداد پیام‌های خام یک کانال از SUMMARY_TRIGGER_MESSAGES بیشتر شده،
    قدیمی‌ترها رو با یه مدل ارزون خلاصه می‌کنه، خلاصه‌ی قبلی رو باهاش ادغام
    می‌کنه، و ردیف‌های خام قدیمی رو پاک می‌کنه (فقط SUMMARY_KEEP_RECENT تای
    آخر خام می‌مونه). این تابع نباید کل ربات رو کند کنه، پس خطاهاش رو می‌بلعه
    و فقط لاگ می‌کنه؛ شکست summarization نباید مانع کارکرد چت بشه.
    """
    import logging
    import clients.groq_client as groq_client

    log = logging.getLogger("agentbot.memory")

    async with aiosqlite.connect(config.DB_PATH) as db:
        count_cursor = await db.execute(
            "SELECT COUNT(*) FROM messages WHERE channel_id = ?", (channel_id,)
        )
        (total,) = await count_cursor.fetchone()
        if total <= SUMMARY_TRIGGER_MESSAGES:
            return

        to_summarize_count = total - SUMMARY_KEEP_RECENT
        old_cursor = await db.execute(
            "SELECT id, role, content FROM messages WHERE channel_id = ? "
            "ORDER BY id ASC LIMIT ?",
            (channel_id, to_summarize_count),
        )
        old_rows = await old_cursor.fetchall()

        existing_cursor = await db.execute(
            "SELECT summary FROM summaries WHERE channel_id = ?", (channel_id,)
        )
        existing_row = await existing_cursor.fetchone()
        existing_summary = existing_row[0] if existing_row else ""

    if not old_rows:
        return

    transcript = "\n".join(
        f"{role}: {content[:MAX_MESSAGE_CHARS_FOR_CONTEXT]}" for _, role, content in old_rows
    )
    prompt = (
        "این بخشی از یک مکالمه‌ی قدیمی‌تره. یک خلاصه‌ی کوتاه و فشرده (حداکثر ۸-۱۰ خط) "
        "به فارسی بنویس که نکات مهم، تصمیم‌ها، ترجیحات کاربر و context لازم برای ادامه‌ی "
        "مکالمه رو حفظ کنه. جزئیات غیرضروری رو حذف کن.\n\n"
        f"خلاصه‌ی قبلی (اگه بود): {existing_summary or '(هیچی)'}\n\n"
        f"مکالمه‌ی جدید برای ادغام:\n{transcript}"
    )

    try:
        new_summary = await groq_client.chat(
            [
                {"role": "system", "content": "تو یک خلاصه‌ساز دقیق و فشرده هستی."},
                {"role": "user", "content": prompt},
            ],
            model=config.GROQ_ROUTER_MODEL,  # مدل کوچیک و ارزون کافیه
            temperature=0.2,
            max_tokens=400,
        )
    except Exception:
        log.exception(f"خلاصه‌سازی حافظه برای کانال {channel_id} شکست خورد")
        return

    old_ids = [row[0] for row in old_rows]
    async with aiosqlite.connect(config.DB_PATH) as db:
        await db.execute(
            "INSERT INTO summaries (channel_id, summary, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(channel_id) DO UPDATE SET summary = excluded.summary, "
            "updated_at = excluded.updated_at",
            (channel_id, new_summary.strip(), time.time()),
        )
        await db.executemany(
            "DELETE FROM messages WHERE id = ?", [(i,) for i in old_ids]
        )
        await db.commit()

    log.info(f"حافظه‌ی کانال {channel_id} خلاصه شد ({len(old_ids)} پیام قدیمی جمع‌بندی شد).")


# ---------------------------------------------------------------------------
# تنظیمات «کجا ربات بدون نیاز به mention چت می‌کنه»: یک کانال مشخص در هر سرور
# + هر ثریدی که با /chat ساخته شده. این‌ها با پنل ادمین (cogs/admin.py) تنظیم می‌شن.
# ---------------------------------------------------------------------------

async def set_ai_channel(guild_id: int, channel_id: int | None):
    """کانال گفتگوی آزاد با AI رو برای یک سرور تنظیم می‌کنه (None = غیرفعال)."""
    async with aiosqlite.connect(config.DB_PATH) as db:
        await db.execute(
            "INSERT INTO guild_settings (guild_id, ai_channel_id, threads_enabled, updated_at) "
            "VALUES (?, ?, 1, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET ai_channel_id = excluded.ai_channel_id, "
            "updated_at = excluded.updated_at",
            (guild_id, channel_id, time.time()),
        )
        await db.commit()


async def get_ai_channel(guild_id: int) -> int | None:
    async with aiosqlite.connect(config.DB_PATH) as db:
        cursor = await db.execute(
            "SELECT ai_channel_id FROM guild_settings WHERE guild_id = ?", (guild_id,)
        )
        row = await cursor.fetchone()
    return row[0] if row and row[0] else None


async def set_threads_enabled(guild_id: int, enabled: bool):
    async with aiosqlite.connect(config.DB_PATH) as db:
        await db.execute(
            "INSERT INTO guild_settings (guild_id, ai_channel_id, threads_enabled, updated_at) "
            "VALUES (?, NULL, ?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET threads_enabled = excluded.threads_enabled, "
            "updated_at = excluded.updated_at",
            (guild_id, int(enabled), time.time()),
        )
        await db.commit()


async def are_threads_enabled(guild_id: int) -> bool:
    async with aiosqlite.connect(config.DB_PATH) as db:
        cursor = await db.execute(
            "SELECT threads_enabled FROM guild_settings WHERE guild_id = ?", (guild_id,)
        )
        row = await cursor.fetchone()
    # پیش‌فرض: فعال (اگه سرور هیچ تنظیمی نداشته باشه)
    return True if row is None else bool(row[0])


async def register_ai_thread(thread_id: int, owner_id: int):
    async with aiosqlite.connect(config.DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO ai_threads (thread_id, owner_id, created_at) VALUES (?, ?, ?)",
            (thread_id, owner_id, time.time()),
        )
        await db.commit()


async def is_ai_thread(thread_id: int) -> bool:
    async with aiosqlite.connect(config.DB_PATH) as db:
        cursor = await db.execute(
            "SELECT 1 FROM ai_threads WHERE thread_id = ?", (thread_id,)
        )
        row = await cursor.fetchone()
    return row is not None
