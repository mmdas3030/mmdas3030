"""
محدودکننده‌ی نرخ درخواست، ساده و در حافظه (sliding window per کاربر).

هدف: جلوگیری از سواستفاده/اسپم که مستقیم روی هزینه‌ی API (Groq/Cerebras/
Mistral) اثر می‌ذاره. این یه راه‌حل توزیع‌شده نیست (per-process)، ولی برای
یک ربات دیسکورد تک‌پردازه‌ای کاملاً کافیه. اگه بعداً روی چند instance اجرا
شد، باید به Redis یا مشابه منتقل بشه.
"""
import time
from collections import defaultdict, deque

import config

# پیش‌فرض: هر کاربر حداکثر ۸ درخواست AI در هر ۶۰ ثانیه
MAX_CALLS = int(getattr(config, "RATE_LIMIT_MAX_CALLS", 8))
WINDOW_SECONDS = int(getattr(config, "RATE_LIMIT_WINDOW_SECONDS", 60))

_calls: dict[int, deque] = defaultdict(deque)


def check(user_id: int) -> tuple[bool, float]:
    """
    برمی‌گردونه: (اجازه داره؟, اگه نه چند ثانیه دیگه صبر کنه)
    این تابع خودش یه تلاش رو ثبت نمی‌کنه؛ صرفاً چک می‌کنه. برای ثبت،
    از record() استفاده کن (بعد از این‌که مطمئن شدی درخواست واقعاً پردازش می‌شه).
    """
    now = time.time()
    q = _calls[user_id]
    while q and now - q[0] > WINDOW_SECONDS:
        q.popleft()
    if len(q) >= MAX_CALLS:
        retry_after = WINDOW_SECONDS - (now - q[0])
        return False, max(retry_after, 0.0)
    return True, 0.0


def record(user_id: int):
    _calls[user_id].append(time.time())
