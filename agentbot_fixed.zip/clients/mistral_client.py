"""
Wrapper برای Mistral. اگه MISTRAL_AGENT_ID تنظیم شده باشه از Agents/Conversations
API استفاده می‌کنیم (که ابزارهای built-in مثل code_interpreter رو هم داره)،
وگرنه fallback می‌کنیم به چت‌کامپلیشن ساده با یه مدل عمومی.
"""
import logging

# از نسخه‌ی ۲ کتابخونه‌ی mistralai به بعد، مسیر import عوض شده
# (mistralai.client به‌جای mistralai). این fallback باعث می‌شه با هر دو
# نسخه کار کنه، صرف‌نظر از اینکه pip کدوم رو نصب کرده.
try:
    from mistralai import Mistral
except ImportError:
    from mistralai.client import Mistral

import config

log = logging.getLogger("agentbot.mistral")

_client = Mistral(api_key=config.MISTRAL_API_KEY)

# حافظه conversation_id برای هر کاربر/کانال (اختیاری - ادامه‌ی مکالمه با ایجنت)
_active_conversations: dict[int, str] = {}


async def chat(
    messages: list[dict],
    model: str = "mistral-small-latest",
    temperature: float = 0.5,
    max_tokens: int = 4096,
) -> str:
    """
    فراخوانی مستقیم Chat Completion (بدون ایجنت/ابزار)، برای مدل‌های عمومی
    Mistral مثل mistral-large-latest / mistral-medium-latest / mistral-small-latest.
    """
    try:
        resp = await _client.chat.complete_async(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return resp.choices[0].message.content or ""
    except Exception as e:
        log.exception("خطا در فراخوانی Mistral (chat)")
        raise RuntimeError(f"خطا در ارتباط با Mistral: {e}") from e


async def chat_with_tools(
    messages: list[dict],
    tools: list[dict],
    model: str = "mistral-large-latest",
    temperature: float = 0.3,
    max_tokens: int = 4096,
):
    """
    مثل chat ولی با function-calling، برای حلقه‌ی ایجنت وقتی کاربر یه مدل
    عمومی Mistral (نه Mistral Agent که سیستم ابزار خودش رو داره) رو صریحاً
    انتخاب کرده باشه. خروجی خودِ پیام مدل رو برمی‌گردونه (ممکنه tool_calls
    داشته باشه).
    """
    try:
        resp = await _client.chat.complete_async(
            model=model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return resp.choices[0].message
    except Exception as e:
        log.exception("خطا در فراخوانی Mistral (tool-calling)")
        raise RuntimeError(f"خطا در ارتباط با Mistral: {e}") from e


async def ask_agent(text: str, session_key: int | None = None) -> str:
    """
    یه پیام به ایجنت مستقر در Mistral می‌فرسته.
    اگه session_key بدی، مکالمه رو ادامه می‌ده (append)، وگرنه شروع تازه.
    """
    if not config.MISTRAL_AGENT_ID:
        raise RuntimeError("MISTRAL_AGENT_ID تنظیم نشده")

    try:
        conv_id = _active_conversations.get(session_key) if session_key else None
        if conv_id:
            resp = await _client.beta.conversations.append_async(
                conversation_id=conv_id, inputs=text
            )
        else:
            resp = await _client.beta.conversations.start_async(
                agent_id=config.MISTRAL_AGENT_ID, inputs=text
            )
            if session_key:
                _active_conversations[session_key] = resp.conversation_id

        # آخرین خروجی متنی رو استخراج می‌کنیم
        for entry in reversed(resp.outputs):
            if getattr(entry, "type", "") == "message.output":
                content = entry.content
                if isinstance(content, str):
                    return content
                # اگه content لیستی از بلوک‌هاست
                if isinstance(content, list):
                    return "".join(
                        c.text for c in content if getattr(c, "type", "") == "text"
                    )
        return "پاسخی از ایجنت دریافت نشد."
    except Exception as e:
        log.exception("خطا در فراخوانی Mistral Agent")
        raise RuntimeError(f"خطا در ارتباط با Mistral: {e}") from e


def reset_session(session_key: int):
    _active_conversations.pop(session_key, None)
