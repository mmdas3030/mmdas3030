"""
Wrapper برای Cerebras. مناسب برای تسک‌های کدنویسی سنگین یا وقتی سرعت
خیلی بالا لازمه (Cerebras روی سخت‌افزار مخصوص AI اجرا می‌شه).

⚠️ نکته: بیشتر مدل‌های خوب Cerebras روی endpoint عمومی حالت «Preview»
دارن و ممکنه بدون اطلاع قبلی تغییر/حذف بشن (برخلاف gpt-oss-120b که
Production و پایداره). به همین خاطر اگه فراخوانی با مدل preview
شکست بخوره، خودکار روی مدل production فال‌بک می‌کنیم تا کاربر یهو
با خطای خام روبه‌رو نشه.
"""
import logging
from cerebras.cloud.sdk import AsyncCerebras
import config

log = logging.getLogger("agentbot.cerebras")

_client = AsyncCerebras(api_key=config.CEREBRAS_API_KEY)

# مدل پایدار Production که همیشه به‌عنوان fallback در دسترسه
_FALLBACK_MODEL = "gpt-oss-120b"


async def chat(
    messages: list[dict],
    model: str = config.CEREBRAS_CODE_MODEL,
    temperature: float = 0.3,
    max_tokens: int = 2048,
    _is_fallback_attempt: bool = False,
) -> str:
    try:
        resp = await _client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return resp.choices[0].message.content or ""
    except Exception as e:
        log.exception(f"خطا در فراخوانی Cerebras با مدل {model}")
        if not _is_fallback_attempt and model != _FALLBACK_MODEL:
            log.warning(f"تلاش دوباره با مدل fallback: {_FALLBACK_MODEL}")
            try:
                return await chat(
                    messages,
                    model=_FALLBACK_MODEL,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    _is_fallback_attempt=True,
                )
            except Exception as e2:
                raise RuntimeError(f"خطا در ارتباط با Cerebras (حتی با fallback): {e2}") from e2
        raise RuntimeError(f"خطا در ارتباط با Cerebras: {e}") from e


async def chat_with_tools(
    messages: list[dict],
    tools: list[dict],
    model: str = config.CEREBRAS_CODE_MODEL,
    temperature: float = 0.3,
    max_tokens: int = 2048,
):
    """
    مثل chat ولی از function-calling پشتیبانی می‌کنه، برای استفاده در حلقه‌ی
    ایجنت (agent.py) وقتی کاربر مدل Cerebras رو صریحاً انتخاب کرده باشه.
    خروجی خودِ پیام مدل رو برمی‌گردونه (نه فقط رشته)، چون ممکنه tool_calls
    داشته باشه.
    """
    try:
        resp = await _client.chat.completions.create(
            model=model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return resp.choices[0].message
    except Exception as e:
        log.exception(f"خطا در فراخوانی Cerebras (tool-calling) با مدل {model}")
        raise RuntimeError(f"خطا در ارتباط با Cerebras: {e}") from e
