"""
Wrapper سبک برای Groq.
همیشه async client استفاده می‌کنیم چون توی دیسکورد باتِ async هستیم
و نباید event loop رو بلاک کنیم.
"""
import logging
from groq import AsyncGroq
import config

log = logging.getLogger("agentbot.groq")

_client = AsyncGroq(api_key=config.GROQ_API_KEY)


async def chat(
    messages: list[dict],
    model: str = config.GROQ_CHAT_MODEL,
    temperature: float = 0.7,
    max_tokens: int = 4096,
) -> str:
    """یک درخواست چت ساده می‌فرسته و متن پاسخ رو برمی‌گردونه."""
    try:
        resp = await _client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            max_completion_tokens=max_tokens,
        )
        return resp.choices[0].message.content or ""
    except Exception as e:
        log.exception("خطا در فراخوانی Groq")
        raise RuntimeError(f"خطا در ارتباط با Groq: {e}") from e


async def classify(system_prompt: str, user_text: str) -> str:
    """
    یه فراخوانی سریع و ارزون با مدل کوچیک، برای تصمیم‌گیری‌های داخلی
    (مثل روتینگ). خروجی معمولاً یه کلمه یا JSON کوتاهه.
    """
    resp = await _client.chat.completions.create(
        model=config.GROQ_ROUTER_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_text},
        ],
        temperature=0.0,
        max_completion_tokens=50,
    )
    return (resp.choices[0].message.content or "").strip()


async def chat_with_tools(
    messages: list[dict],
    tools: list[dict],
    model: str = config.GROQ_CHAT_MODEL,
    temperature: float = 0.3,
    max_tokens: int = 4096,
):
    """
    مثل chat ولی از function-calling پشتیبانی می‌کنه (برای حلقه‌ی ایجنت/ReAct).
    خروجی خودِ پیام مدل رو برمی‌گردونه (نه فقط رشته)، چون ممکنه به‌جای متن،
    tool_calls داشته باشه که caller باید پردازششون کنه.
    """
    try:
        resp = await _client.chat.completions.create(
            model=model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            temperature=temperature,
            max_completion_tokens=max_tokens,
        )
        return resp.choices[0].message
    except Exception as e:
        log.exception("خطا در فراخوانی Groq (tool-calling)")
        raise RuntimeError(f"خطا در ارتباط با Groq: {e}") from e
