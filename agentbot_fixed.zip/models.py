"""
کاتالوگ مدل‌های قابل‌انتخاب توسط کاربر.

هر گزینه یه (provider, model_id, label فارسی) هست. این فایل تنها منبع
حقیقتِ «چه مدل‌هایی قابل‌انتخابن» هست، هم برای دستور اسلش /model و هم
برای منطق داخلی چت. اگه یه مدل جدید اضافه شد یا قدیمی حذف/deprecate شد،
فقط همینجا رو آپدیت کن.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class ModelOption:
    key: str          # شناسه‌ی داخلی که توی دیتابیس ذخیره می‌شه، مثلاً "cerebras:zai-glm-4.7"
    provider: str      # "groq" | "cerebras" | "mistral"
    model_id: str      # اسم دقیقی که باید به API فرستاده بشه
    label: str         # چیزی که کاربر توی دیسکورد می‌بینه
    description: str   # توضیح کوتاه برای راهنمایی انتخاب
    supports_tools: bool = False  # می‌تونه run_python/write_file/... رو در حین چت صدا بزنه؟
    max_tokens: int | None = None  # سقف اختصاصی؛ None یعنی از پیش‌فرض provider استفاده کن
    history_limit: int | None = None  # سقف تعداد پیام‌های قبلی؛ برای مدل‌های context کوچیک


CATALOG: list[ModelOption] = [
    ModelOption(
        key="auto",
        provider="auto",
        model_id="",
        label="🤖 خودکار (پیش‌فرض)",
        description="ربات خودش بر اساس نوع پیام بهترین مدل رو انتخاب می‌کنه",
    ),

    # ---- Groq ----
    # نکته: llama-3.3-70b-versatile و llama-3.1-8b-instant سهمیه‌ی on_demand
    # tier‌شون پایینه (~۱۲۰۰۰ توکن در دقیقه)، برای همین max_tokens پایین‌تری
    # نسبت به بقیه‌ی مدل‌های Groq براشون تنظیم می‌شه (پایین‌تر همین فایل).
    ModelOption(
        key="groq:openai/gpt-oss-120b",
        provider="groq",
        model_id="openai/gpt-oss-120b",
        label="⚡ Groq · GPT-OSS 120B",
        description="مدل تولیدیِ اصلیِ Groq؛ استدلال قوی، سرعت خیلی بالا",
        supports_tools=True,
    ),
    ModelOption(
        key="groq:openai/gpt-oss-20b",
        provider="groq",
        model_id="openai/gpt-oss-20b",
        label="⚡ Groq · GPT-OSS 20B",
        description="سبک‌تر و سریع‌تر از ۱۲۰B، مناسب سوال‌های روزمره",
        supports_tools=True,
    ),
    ModelOption(
        key="groq:qwen/qwen3.6-27b",
        provider="groq",
        model_id="qwen/qwen3.6-27b",
        label="⚡ Groq · Qwen3.6 27B",
        description="گزینه‌ی جایگزین قوی برای استدلال و کدنویسی",
        supports_tools=True,
    ),
    ModelOption(
        key="groq:groq/compound",
        provider="groq",
        model_id="groq/compound",
        label="🔎 Groq · Compound (وب‌سرچ + اجرای کد توکار)",
        description="یه سیستم agentic که خودش می‌تونه وب‌سرچ کنه و کد اجرا کنه؛ برای سوال‌های به‌روز خیلی خوبه",
    ),
    ModelOption(
        key="groq:groq/compound-mini",
        provider="groq",
        model_id="groq/compound-mini",
        label="🔎 Groq · Compound Mini",
        description="نسخه‌ی سبک‌تر Compound، سریع‌تر ولی همچنان با وب‌سرچ/اجرای کد",
    ),
    ModelOption(
        key="groq:llama-3.3-70b-versatile",
        provider="groq",
        model_id="llama-3.3-70b-versatile",
        label="⚡ Groq · Llama 3.3 70B",
        description="همه‌کاره و آشنا؛ سهمیه‌ی پایین‌تری داره، برای پیام‌های خیلی طولانی مناسب نیست",
        max_tokens=1500,
    ),
    ModelOption(
        key="groq:llama-3.1-8b-instant",
        provider="groq",
        model_id="llama-3.1-8b-instant",
        label="⚡ Groq · Llama 3.1 8B",
        description="خیلی سریع؛ سهمیه‌ی پایین‌تری داره، برای پیام‌های خیلی طولانی مناسب نیست",
        max_tokens=1500,
    ),

    # ---- Cerebras ----
    ModelOption(
        key="cerebras:zai-glm-4.7",
        provider="cerebras",
        model_id="zai-glm-4.7",
        label="🚀 Cerebras · GLM-4.7 (Preview)",
        description="قوی‌ترین گزینه برای کد و استدلال، سرعت فوق‌العاده (⚠️ context کوچیک: ۸۱۹۲)",
        supports_tools=True,
        max_tokens=1200,
        history_limit=4,
    ),
    ModelOption(
        key="cerebras:gpt-oss-120b",
        provider="cerebras",
        model_id="gpt-oss-120b",
        label="🚀 Cerebras · GPT-OSS 120B",
        description="مدل تولیدی و پایدار Cerebras، سرعت خیلی بالا",
        supports_tools=True,
    ),
    ModelOption(
        key="cerebras:gemma-4-31b",
        provider="cerebras",
        model_id="gemma-4-31b",
        label="🚀 Cerebras · Gemma 4 31B (Preview)",
        description="سبک‌تر و سریع، جایگزین خوب برای تسک‌های ساده‌تر کد",
    ),

    # ---- Mistral ----
    ModelOption(
        key="mistral:mistral-large-latest",
        provider="mistral",
        model_id="mistral-large-2512",  # alias «-latest» توی این اکانت لیست/quota نداشت؛ نسخه‌ی تاریخ‌دار مطمئنه
        label="🇫🇷 Mistral · Large",
        description="پرچمدار Mistral؛ برای استدلال و تسک‌های پیچیده‌ی متنی",
        supports_tools=True,
    ),
    ModelOption(
        key="mistral:mistral-medium-latest",
        provider="mistral",
        model_id="mistral-medium-latest",
        label="🇫🇷 Mistral · Medium",
        description="تعادل خوب بین سرعت و کیفیت",
        supports_tools=True,
    ),
    ModelOption(
        key="mistral:mistral-small-latest",
        provider="mistral",
        model_id="mistral-small-2506",  # quota خیلی بالاتری نسبت به بقیه‌ی نسخه‌های Small داره
        label="🇫🇷 Mistral · Small",
        description="سریع و ارزون، مناسب چت روزمره",
    ),
    ModelOption(
        key="mistral:agent",
        provider="mistral",
        model_id="agent",
        label="🧠 Mistral Agent (ابزارمند)",
        description="برای محاسبات دقیق، اجرای کد و استدلال چندمرحله‌ای (نیاز به MISTRAL_AGENT_ID)",
    ),
]

_BY_KEY = {opt.key: opt for opt in CATALOG}


def get(key: str) -> ModelOption | None:
    return _BY_KEY.get(key)


def choices_for_slash_command() -> list[tuple[str, str]]:
    """(نام نمایشی, key) برای app_commands.Choice"""
    return [(opt.label, opt.key) for opt in CATALOG]
