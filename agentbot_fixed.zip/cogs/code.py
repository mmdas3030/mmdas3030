"""
Cog دستیار کدنویسی:
/code   -> تولید/توضیح کد با Cerebras (سریع، مناسب کد سنگین)
/run    -> اجرای واقعی یک قطعه کد پایتون در sandbox
"""
import logging
import discord
from discord import app_commands
from discord.ext import commands

import clients.cerebras_client as cerebras_client
import clients.mistral_client as mistral_client
import ratelimit
import sandbox

log = logging.getLogger("agentbot.code")

CODE_SYSTEM_PROMPT = (
    "تو یک دستیار کدنویسی حرفه‌ای هستی. کدی که می‌نویسی باید تمیز، مدرن و "
    "مطابق جدیدترین best-practiceهای زبان مربوطه باشه. توضیحات رو به فارسی "
    "بده ولی کد و نام متغیرها رو استاندارد (انگلیسی) نگه دار. همیشه کد رو "
    "داخل بلاک کد markdown با نام زبان مشخص بذار."
)


class CodeCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def _check_rate_limit(self, interaction: discord.Interaction) -> bool:
        """اگه کاربر از حد مجاز رد شده، پیام مناسب می‌ده و False برمی‌گردونه."""
        allowed, retry_after = ratelimit.check(interaction.user.id)
        if not allowed:
            await interaction.response.send_message(
                f"⏳ یکم آروم‌تر! لطفاً حدود {retry_after:.0f} ثانیه دیگه دوباره امتحان کن.",
                ephemeral=True,
            )
            return False
        ratelimit.record(interaction.user.id)
        return True

    @app_commands.command(name="code", description="تولید یا توضیح کد با هوش مصنوعی")
    @app_commands.describe(prompt="چی می‌خوای بنویسم یا توضیح بدم؟")
    async def code(self, interaction: discord.Interaction, prompt: str):
        if not await self._check_rate_limit(interaction):
            return
        await interaction.response.defer(thinking=True)
        try:
            reply = await cerebras_client.chat(
                [
                    {"role": "system", "content": CODE_SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.2,
            )
            if len(reply) > 1900:
                # به‌صورت فایل بفرست تا محدودیت پیام دیسکورد مشکل نسازه
                import io
                buf = io.BytesIO(reply.encode("utf-8"))
                await interaction.followup.send(
                    "پاسخ طولانی بود، به‌صورت فایل فرستادم:",
                    file=discord.File(buf, filename="response.md"),
                )
            else:
                await interaction.followup.send(reply)
        except Exception as e:
            log.exception("خطا در /code")
            await interaction.followup.send(f"⚠️ خطا: {e}")

    @app_commands.command(name="run", description="اجرای یک قطعه کد پایتون در sandbox امن")
    @app_commands.describe(code="کد پایتونی که می‌خوای اجرا بشه")
    async def run(self, interaction: discord.Interaction, code: str):
        if not await self._check_rate_limit(interaction):
            return
        await interaction.response.defer(thinking=True)
        try:
            ok, output = await sandbox.run_python(code)
            emoji = "✅" if ok else "❌"
            await interaction.followup.send(f"{emoji} ```\n{output}\n```")
        except Exception as e:
            log.exception("خطا در /run")
            await interaction.followup.send(f"⚠️ خطا: {e}")


    @app_commands.command(name="ask_agent", description="صحبت مستقیم با ایجنت Mistral (برای محاسبات دقیق و استدلال چندمرحله‌ای)")
    @app_commands.describe(prompt="سوالت چیه؟")
    async def ask_agent(self, interaction: discord.Interaction, prompt: str):
        if not await self._check_rate_limit(interaction):
            return
        await interaction.response.defer(thinking=True)
        try:
            reply = await mistral_client.ask_agent(prompt, session_key=interaction.channel_id)
            for i in range(0, len(reply), 1900):
                await interaction.followup.send(reply[i:i + 1900])
        except Exception as e:
            log.exception("خطا در /ask_agent")
            await interaction.followup.send(f"⚠️ خطا: {e}")

    @app_commands.command(name="agent_reset", description="شروع تازه‌ی جلسه‌ی ایجنت Mistral در این کانال")
    async def agent_reset(self, interaction: discord.Interaction):
        mistral_client.reset_session(interaction.channel_id)
        await interaction.response.send_message("🔄 جلسه‌ی ایجنت ریست شد.", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(CodeCog(bot))
