"""
Cog اصلی چت: پیام‌های عادی کاربر رو می‌گیره (وقتی ربات mention بشه یا با
پیشوند خاص صحبت بشه)، روتینگ می‌کنه (یا از مدل انتخابیِ کاربر استفاده
می‌کنه)، و از حافظه‌ی SQLite استفاده می‌کنه.
"""
import logging
import os
import discord
from discord.ext import commands
from discord import app_commands

import agent
import config
import memory
import models
import ratelimit
import router
import clients.groq_client as groq_client
import clients.cerebras_client as cerebras_client
import clients.mistral_client as mistral_client

log = logging.getLogger("agentbot.chat")

SYSTEM_PROMPT = (
    "تو یک دستیار هوش مصنوعی همه‌کاره و باحال توی یک سرور دیسکورد فارسی‌زبان هستی. "
    "شخصیتت گرم، شوخ‌طبع و دوستانه‌ست؛ از ایموجی مناسب استفاده می‌کنی ولی زیاده‌روی نمی‌کنی. "
    "همیشه به فارسی روان و محاوره‌ای پاسخ بده مگر اینکه کاربر زبان دیگه‌ای بخواد. "
    "پاسخ‌هات مفید، دقیق و مختصرن مگر توضیح مفصل خواسته بشه. رسمی و خشک صحبت نکن."
)


def _split_message(text: str, limit: int = config.DISCORD_MAX_MESSAGE) -> list[str]:
    """پیام‌های طولانی رو برای ارسال در دیسکورد تیکه‌تیکه می‌کنه."""
    if len(text) <= limit:
        return [text]
    chunks = []
    while text:
        chunks.append(text[:limit])
        text = text[limit:]
    return chunks


async def _generate_reply(
    channel_id: int, content: str, history: list[dict], on_progress=None
) -> tuple[str, list[str]]:
    """
    مسیر تصمیم‌گیری اصلی: اول چک می‌کنیم کاربر مدل خاصی برای این کانال
    انتخاب کرده یا نه.
    - اگه انتخاب کرده و اون مدل «قوی» باشه (models.py: supports_tools=True)،
      از حلقه‌ی ایجنت (agent.py) با همون provider/مدل استفاده می‌کنیم؛ یعنی
      اجرای کد، ساخت/ویرایش/خوندن فایل و... حین چت آزاد هم در دسترسه.
    - اگه مدل «ضعیف/deprecated/preview سبک» باشه (llama های منسوخ، Gemma 4
      31B، Mistral Small، Compound) یا Mistral Agent باشه (که سیستم ابزار
      مخصوص خودش رو داره)، عمداً از حلقه‌ی ابزارمند رد نمی‌شه چون این مدل‌ها
      برای tool-calling چندمرحله‌ای قابل‌اعتماد نیستن و ممکنه خروجی خراب بدن.
    - اگه هیچ مدلی انتخاب نشده (auto)، روتینگ خودکار قبلی اجرا می‌شه.

    خروجی همیشه (متن پاسخ, لیست مسیر فایل‌های ساخته/ویرایش‌شده) هست.
    """
    messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history + [
        {"role": "user", "content": content}
    ]

    pref_key = await memory.get_model_preference(channel_id)
    if pref_key:
        opt = models.get(pref_key)
        if opt is not None:
            if opt.history_limit is not None and len(history) > opt.history_limit:
                # مدل‌هایی مثل zai-glm-4.7 context خیلی کوچیکی دارن (۸۱۹۲)؛
                # اگه کل تاریخچه رو بفرستیم فوراً context_length_exceeded می‌ده.
                history = history[-opt.history_limit:]
                messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history + [
                    {"role": "user", "content": content}
                ]
            if opt.provider == "mistral" and opt.model_id == "agent":
                if not config.MISTRAL_AGENT_ID:
                    return "⚠️ Mistral Agent تنظیم نشده. با /model یه گزینه‌ی دیگه انتخاب کن.", []
                return await mistral_client.ask_agent(content, session_key=channel_id), []
            if opt.supports_tools:
                return await agent.run(
                    content, history, channel_id=channel_id,
                    model=opt.model_id, provider=opt.provider,
                    on_progress=on_progress,
                )
            if opt.provider == "groq":
                kw = {"max_tokens": opt.max_tokens} if opt.max_tokens else {}
                return await groq_client.chat(messages, model=opt.model_id, **kw), []
            if opt.provider == "cerebras":
                kw = {"max_tokens": opt.max_tokens} if opt.max_tokens else {}
                return await cerebras_client.chat(messages, model=opt.model_id, **kw), []
            if opt.provider == "mistral":
                kw = {"max_tokens": opt.max_tokens} if opt.max_tokens else {}
                return await mistral_client.chat(messages, model=opt.model_id, **kw), []
        # اگه opt is None یعنی کلید نامعتبر شده (مثلاً مدل حذف شد)؛ برمی‌گردیم به auto

    # ---- حالت auto: روتینگ خودکار ----
    kind = await router.route(content)
    if kind in ("code", "agent"):
        # هر دو از حلقه‌ی ReAct داخلی خودمون (agent.py) رد می‌شن: مدل می‌تونه
        # واقعاً کد اجرا کنه، فایل واقعی بسازه/بخونه/ویرایش کنه، نتیجه رو
        # ببینه و خودش رو اصلاح کنه.
        return await agent.run(content, history, channel_id=channel_id, on_progress=on_progress)
    return await groq_client.chat(messages), []


class ChatCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot:
            return

        is_dm = isinstance(message.channel, discord.DMChannel)
        is_mention = self.bot.user in message.mentions

        # اگه ریپلای به یکی از پیام‌های خود ربات باشه، بدون mention هم جواب بده
        is_reply_to_bot = False
        if message.reference and message.reference.resolved:
            ref = message.reference.resolved
            if isinstance(ref, discord.Message) and ref.author.id == self.bot.user.id:
                is_reply_to_bot = True

        # کانال اختصاصیِ چت-با-AI که با /aiconfig set_channel تنظیم شده
        is_ai_channel = False
        if message.guild:
            ai_channel_id = await memory.get_ai_channel(message.guild.id)
            is_ai_channel = ai_channel_id is not None and message.channel.id == ai_channel_id

        # ثریدی که با /chat ساخته شده (چت خصوصیِ بدون نیاز به mention)
        is_ai_thread = isinstance(message.channel, discord.Thread) and await memory.is_ai_thread(
            message.channel.id
        )

        if not (is_dm or is_mention or is_reply_to_bot or is_ai_channel or is_ai_thread):
            return

        content = message.content.replace(f"<@{self.bot.user.id}>", "").strip()
        if not content:
            await message.reply("سلام! 👋 چطور می‌تونم کمکت کنم؟")
            return

        allowed, retry_after = ratelimit.check(message.author.id)
        if not allowed:
            await message.reply(
                f"⏳ یکم آروم‌تر! لطفاً حدود {retry_after:.0f} ثانیه دیگه دوباره امتحان کن."
            )
            return

        async with message.channel.typing():
            try:
                ratelimit.record(message.author.id)
                history = await memory.get_history(message.channel.id)

                async def _on_progress(text: str):
                    # پیام میان‌راه؛ خطای ارسال نباید کل تسک ایجنت رو متوقف کنه
                    try:
                        await message.channel.send(text)
                    except discord.DiscordException:
                        log.exception("فرستادن پیام میان‌راه شکست خورد")

                reply, files = await _generate_reply(
                    message.channel.id, content, history, on_progress=_on_progress
                )

                await memory.add_message(message.channel.id, "user", content)
                await memory.add_message(message.channel.id, "assistant", reply)
                await memory.maybe_summarize(message.channel.id)

                chunks = _split_message(reply)
                # دیسکورد بیشتر از ۱۰ فایل توی یک پیام قبول نمی‌کنه؛ اگه ایجنت
                # بیشتر از ۱۰ فایل ساخته باشه، توی گروه‌های ۱۰تایی جدا می‌فرستیم.
                file_batches = [files[i:i + 10] for i in range(0, len(files), 10)] or [[]]

                for i, chunk in enumerate(chunks):
                    # فایل‌های دسته‌ی اول رو با آخرین تیکه‌ی پیام می‌فرستیم
                    attach = None
                    if i == len(chunks) - 1 and file_batches[0]:
                        attach = [discord.File(p, filename=os.path.basename(p)) for p in file_batches[0]]
                    await message.reply(chunk, files=attach)

                # اگه بیش از ۱۰ فایل بود، بقیه‌ی دسته‌ها رو با پیام‌های جدا می‌فرستیم
                for batch in file_batches[1:]:
                    discord_files = [discord.File(p, filename=os.path.basename(p)) for p in batch]
                    await message.channel.send(files=discord_files)
            except Exception as e:
                log.exception("خطا در پردازش پیام چت")
                await message.reply(f"⚠️ یه خطا پیش اومد: {e}")

    @app_commands.command(name="reset", description="پاک‌کردن حافظه‌ی مکالمه در این کانال")
    async def reset(self, interaction: discord.Interaction):
        await memory.clear_history(interaction.channel_id)
        await interaction.response.send_message("🧹 حافظه‌ی این کانال پاک شد.", ephemeral=True)

    @app_commands.command(name="chat", description="یه ثرید خصوصی می‌سازه تا بدون نیاز به mention با AI چت کنی")
    async def chat_thread(self, interaction: discord.Interaction):
        if isinstance(interaction.channel, discord.DMChannel):
            await interaction.response.send_message(
                "توی پیوی همین الانشم می‌تونی مستقیم پیام بدی، نیازی به ثرید نیست 🙂",
                ephemeral=True,
            )
            return

        if interaction.guild and not await memory.are_threads_enabled(interaction.guild.id):
            await interaction.response.send_message(
                "⛔ ساخت ثرید چت توسط ادمین این سرور غیرفعال شده.", ephemeral=True
            )
            return

        if not isinstance(interaction.channel, discord.TextChannel):
            await interaction.response.send_message(
                "این دستور فقط توی کانال‌های متنی معمولی کار می‌کنه.", ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)
        thread_name = f"چت با AI - {interaction.user.display_name}"[:100]

        thread = None
        try:
            thread = await interaction.channel.create_thread(
                name=thread_name,
                type=discord.ChannelType.private_thread,
                invitable=False,
            )
        except discord.HTTPException:
            # بعضی سرورها ثرید خصوصی رو ساپورت نمی‌کنن؛ fallback به ثرید عمومی
            try:
                thread = await interaction.channel.create_thread(
                    name=thread_name, type=discord.ChannelType.public_thread
                )
            except discord.HTTPException as e:
                log.exception("ساخت ثرید چت شکست خورد")
                await interaction.followup.send(f"⚠️ نتونستم ثرید بسازم: {e}", ephemeral=True)
                return

        try:
            await thread.add_user(interaction.user)
        except discord.HTTPException:
            pass  # اگه اضافه‌کردن دستی fail بشه، حداقل ثرید ساخته شده و کاربر می‌تونه join کنه

        await memory.register_ai_thread(thread.id, interaction.user.id)
        await thread.send(
            f"سلام {interaction.user.mention}! 👋 این یه ثرید اختصاصیه؛ اینجا بدون نیاز "
            f"به mention‌کردن می‌تونی مستقیم باهام چت کنی. هر وقت خواستی حافظه‌ی این "
            f"گفتگو پاک بشه، `/reset` رو بزن."
        )
        await interaction.followup.send(f"✅ ثریدت آماده‌ست: {thread.mention}", ephemeral=True)

    @app_commands.command(name="model", description="انتخاب مدل هوش مصنوعی برای این کانال")
    @app_commands.choices(choice=[
        app_commands.Choice(name=label, value=key)
        for label, key in models.choices_for_slash_command()
    ])
    async def model(self, interaction: discord.Interaction, choice: app_commands.Choice[str]):
        await memory.set_model_preference(interaction.channel_id, choice.value)
        opt = models.get(choice.value)
        if choice.value == "auto":
            await interaction.response.send_message(
                "🤖 مدل روی **خودکار** تنظیم شد؛ از این به بعد ربات خودش بهترین مدل رو انتخاب می‌کنه.",
                ephemeral=True,
            )
        else:
            await interaction.response.send_message(
                f"✅ مدل این کانال روی **{opt.label}** تنظیم شد.\n_{opt.description}_",
                ephemeral=True,
            )

    @app_commands.command(name="model_status", description="دیدن مدل فعلیِ انتخاب‌شده برای این کانال")
    async def model_status(self, interaction: discord.Interaction):
        pref_key = await memory.get_model_preference(interaction.channel_id)
        if not pref_key:
            await interaction.response.send_message(
                "🤖 فعلاً روی حالت **خودکار** هست.", ephemeral=True
            )
            return
        opt = models.get(pref_key)
        label = opt.label if opt else pref_key
        await interaction.response.send_message(f"📌 مدل فعلی: **{label}**", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(ChatCog(bot))
