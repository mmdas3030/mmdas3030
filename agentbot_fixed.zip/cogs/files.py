"""
Cog مربوط به ساخت فایل: کاربر متن/محتوا می‌خواد، ربات یه فایل توی پوشه‌ی
خروجی (پیش‌فرض: MS) می‌سازه و هم توی دیسکورد آپلودش می‌کنه هم روی دیسک نگه می‌داره.
"""
import logging
import os
import re
import discord
from discord import app_commands
from discord.ext import commands

import config
import clients.groq_client as groq_client

log = logging.getLogger("agentbot.files")

_SAFE_NAME = re.compile(r"[^a-zA-Z0-9._-]+")


def _safe_filename(name: str) -> str:
    name = _SAFE_NAME.sub("_", name).strip("_")
    return name or "file.txt"


class FilesCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        os.makedirs(config.OUTPUT_DIR, exist_ok=True)

    @app_commands.command(name="makefile", description="ساخت یک فایل متنی با محتوای هوش مصنوعی")
    @app_commands.describe(filename="نام فایل (مثلاً notes.md)", prompt="محتوای فایل چی باشه؟")
    async def makefile(self, interaction: discord.Interaction, filename: str, prompt: str):
        await interaction.response.defer(thinking=True)
        try:
            content = await groq_client.chat(
                [
                    {
                        "role": "system",
                        "content": "محتوای درخواستی کاربر رو تولید کن. فقط محتوای فایل رو "
                        "برگردون، بدون توضیح اضافه یا بلاک کد اضافی.",
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.5,
                max_tokens=2000,
            )
            safe_name = _safe_filename(filename)
            path = os.path.join(config.OUTPUT_DIR, safe_name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)

            await interaction.followup.send(
                f"📄 فایل ساخته شد و در `{config.OUTPUT_DIR}/{safe_name}` ذخیره شد:",
                file=discord.File(path, filename=safe_name),
            )
        except Exception as e:
            log.exception("خطا در /makefile")
            await interaction.followup.send(f"⚠️ خطا: {e}")


async def setup(bot: commands.Bot):
    await bot.add_cog(FilesCog(bot))
