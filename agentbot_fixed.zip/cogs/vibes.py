"""
یه لایه‌ی سرگرمی سبک و رایگان (بدون فراخوانی AI):
به بعضی کلمات کلیدی توی پیام‌های سرور با ایموجی واکنش نشون می‌ده تا فضا زنده‌تر بشه.
کاملاً غیرمزاحمه: با احتمال کم فعال می‌شه و هیچ پیامی نمی‌فرسته، فقط reaction می‌ذاره.
"""
import random
import discord
from discord.ext import commands

# کلمه‌کلیدی -> لیست ایموجی‌های ممکن
_TRIGGERS: dict[str, list[str]] = {
    "پایتون": ["🐍"],
    "python": ["🐍"],
    "دیسکورد": ["💬"],
    "کد": ["👨‍💻", "⚡"],
    "باگ": ["🐛", "🔥"],
    "خفن": ["🔥", "😎"],
    "عالی": ["🎉", "👏"],
    "خسته": ["😴"],
    "قهوه": ["☕"],
    "پول": ["💰"],
    "پرچمان": ["🏛️"],
    "ربات": ["🤖"],
}

REACTION_CHANCE = 0.35  # احتمال واکنش وقتی یه کلمه‌ی کلیدی پیدا بشه


class VibeCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot:
            return
        text = message.content.lower()
        for keyword, emojis in _TRIGGERS.items():
            if keyword in text and random.random() < REACTION_CHANCE:
                try:
                    await message.add_reaction(random.choice(emojis))
                except discord.HTTPException:
                    pass
                break  # فقط یه واکنش در هر پیام، تا اسپم نشه


async def setup(bot: commands.Bot):
    await bot.add_cog(VibeCog(bot))
