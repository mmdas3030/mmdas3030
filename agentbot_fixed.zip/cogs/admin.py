"""
دستورات مدیریتی سرور. همه‌ی دستورات نیازمند پرمیشن مناسب دیسکورد هستن
(نه فقط چک نام رول) تا امنیت واقعی از خود دیسکورد تضمین بشه.
"""
import datetime
import logging
import discord
from discord import app_commands
from discord.ext import commands

import memory

log = logging.getLogger("agentbot.admin")


aiconfig_group = app_commands.Group(
    name="aiconfig", description="تنظیمات چت با هوش مصنوعی (کانال اختصاصی، ثریدها)"
)


@aiconfig_group.command(name="set_channel", description="یک کانال رو به‌عنوان کانال آزاد چت با AI تنظیم کن")
@app_commands.checks.has_permissions(manage_guild=True)
@app_commands.describe(channel="کانالی که توش بدون نیاز به mention بشه با AI چت کرد")
async def aiconfig_set_channel(interaction: discord.Interaction, channel: discord.TextChannel):
    await memory.set_ai_channel(interaction.guild_id, channel.id)
    await interaction.response.send_message(
        f"✅ از این به بعد توی {channel.mention} می‌شه بدون mention مستقیم با AI چت کرد.",
        ephemeral=True,
    )


@aiconfig_group.command(name="clear_channel", description="غیرفعال‌کردن کانال اختصاصی چت با AI")
@app_commands.checks.has_permissions(manage_guild=True)
async def aiconfig_clear_channel(interaction: discord.Interaction):
    await memory.set_ai_channel(interaction.guild_id, None)
    await interaction.response.send_message("🚫 کانال اختصاصی چت با AI غیرفعال شد.", ephemeral=True)


@aiconfig_group.command(name="threads", description="فعال/غیرفعال‌کردن ساخت ثرید چت با /chat")
@app_commands.checks.has_permissions(manage_guild=True)
@app_commands.describe(enabled="روشن یا خاموش")
async def aiconfig_threads(interaction: discord.Interaction, enabled: bool):
    await memory.set_threads_enabled(interaction.guild_id, enabled)
    state = "فعال" if enabled else "غیرفعال"
    await interaction.response.send_message(f"🧵 ساخت ثرید چت با /chat {state} شد.", ephemeral=True)


@aiconfig_group.command(name="status", description="دیدن تنظیمات فعلی چت با AI در این سرور")
@app_commands.checks.has_permissions(manage_guild=True)
async def aiconfig_status(interaction: discord.Interaction):
    ai_channel_id = await memory.get_ai_channel(interaction.guild_id)
    threads_enabled = await memory.are_threads_enabled(interaction.guild_id)
    channel_text = f"<#{ai_channel_id}>" if ai_channel_id else "تنظیم‌نشده"
    await interaction.response.send_message(
        f"📌 **کانال اختصاصی چت:** {channel_text}\n"
        f"🧵 **ساخت ثرید با /chat:** {'فعال ✅' if threads_enabled else 'غیرفعال ⛔'}\n\n"
        f"_یادآوری: در همه‌جا mention‌کردن ربات، ریپلای به پیام‌هاش، و پیوی همیشه کار می‌کنن._",
        ephemeral=True,
    )


@aiconfig_group.error
async def aiconfig_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        await interaction.response.send_message("⛔ پرمیشن کافی نداری (نیاز به Manage Server).", ephemeral=True)
    else:
        log.exception("خطا در دستورات aiconfig", exc_info=error)
        msg = f"⚠️ خطا: {error}"
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)


class AdminCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="kick", description="اخراج یک عضو از سرور")
    @app_commands.checks.has_permissions(kick_members=True)
    @app_commands.describe(member="عضو موردنظر", reason="دلیل (اختیاری)")
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "نامشخص"):
        await member.kick(reason=reason)
        await interaction.response.send_message(f"👢 {member.mention} اخراج شد. دلیل: {reason}")

    @app_commands.command(name="ban", description="بن‌کردن یک عضو از سرور")
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.describe(member="عضو موردنظر", reason="دلیل (اختیاری)")
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "نامشخص"):
        await member.ban(reason=reason)
        await interaction.response.send_message(f"🔨 {member.mention} بن شد. دلیل: {reason}")

    @app_commands.command(name="mute", description="سکوت موقت یک عضو (تایم‌اوت)")
    @app_commands.checks.has_permissions(moderate_members=True)
    @app_commands.describe(member="عضو موردنظر", minutes="مدت زمان به دقیقه")
    async def mute(self, interaction: discord.Interaction, member: discord.Member, minutes: int):
        until = discord.utils.utcnow() + datetime.timedelta(minutes=minutes)
        await member.timeout(until, reason="با دستور /mute")
        await interaction.response.send_message(f"🔇 {member.mention} به مدت {minutes} دقیقه سکوت شد.")

    @app_commands.command(name="unmute", description="لغو سکوت یک عضو")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def unmute(self, interaction: discord.Interaction, member: discord.Member):
        await member.timeout(None)
        await interaction.response.send_message(f"🔊 سکوت {member.mention} لغو شد.")

    @app_commands.command(name="purge", description="پاک‌کردن چند پیام آخر از کانال")
    @app_commands.checks.has_permissions(manage_messages=True)
    @app_commands.describe(count="تعداد پیام (حداکثر ۱۰۰)")
    async def purge(self, interaction: discord.Interaction, count: app_commands.Range[int, 1, 100]):
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=count)
        await interaction.followup.send(f"🧹 {len(deleted)} پیام پاک شد.", ephemeral=True)

    @app_commands.command(name="slowmode", description="تنظیم slowmode کانال")
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.describe(seconds="ثانیه (۰ برای غیرفعال‌کردن)")
    async def slowmode(self, interaction: discord.Interaction, seconds: app_commands.Range[int, 0, 21600]):
        await interaction.channel.edit(slowmode_delay=seconds)
        await interaction.response.send_message(f"🐌 slowmode روی {seconds} ثانیه تنظیم شد.")

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("⛔ پرمیشن کافی نداری.", ephemeral=True)
        else:
            log.exception("خطای دستور ادمین", exc_info=error)
            if interaction.response.is_done():
                await interaction.followup.send(f"⚠️ خطا: {error}", ephemeral=True)
            else:
                await interaction.response.send_message(f"⚠️ خطا: {error}", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(AdminCog(bot))
    bot.tree.add_command(aiconfig_group)
