"""
روتینگ درخواست‌های چت آزاد (بدون دستور صریح).

استراتژی:
1) اول یه چک کلیدواژه‌ای سریع و رایگان (بدون فراخوانی API) انجام می‌دیم.
2) اگه مطمئن نبودیم، از یه مدل کوچیک و سریع (Groq 8B) به‌عنوان «داور» استفاده
   می‌کنیم تا دسته‌بندی کنه. این یه فراخوانی ارزون و خیلی سریعه.

خروجی یکی از این‌هاست: "code" | "chat" | "creative"
"""
import re
import clients.groq_client as groq_client

_CODE_HINTS = re.compile(
    r"\b(code|debug|error|traceback|exception|function|class|"
    r"کد|دیباگ|خطا|باگ|تابع|کلاس|پایتون|python|جاوااسکریپت|javascript)\b",
    re.IGNORECASE,
)

_CLASSIFY_PROMPT = (
    "You are a routing classifier. Read the user's message and respond with "
    "EXACTLY one word, no punctuation: 'code' if it's about programming, "
    "debugging, or software; 'creative' if it's creative writing, roleplay, "
    "or storytelling; 'agent' if it needs precise math/calculation, multi-step "
    "reasoning, or running code to get an exact numeric/factual answer; "
    "otherwise 'chat'."
)


async def route(text: str) -> str:
    if _CODE_HINTS.search(text):
        return "code"

    if len(text) < 6:
        return "chat"

    try:
        result = await groq_client.classify(_CLASSIFY_PROMPT, text)
        result = result.lower().strip()
        if "code" in result:
            return "code"
        if "creative" in result:
            return "creative"
        if "agent" in result:
            return "agent"
        return "chat"
    except Exception:
        # اگه روتینگ هوشمند شکست خورد، fallback امن به چت عادی
        return "chat"
