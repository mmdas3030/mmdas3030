"""
تنظیمات مرکزی ربات.
همه‌ی مقادیر حساس (کلید API، توکن) از فایل .env خونده می‌شن.
هرگز این مقادیر رو مستقیم توی کد ننویس.
"""
import os
from dotenv import load_dotenv

load_dotenv()


def _get(name: str, default: str | None = None, required: bool = False) -> str:
    val = os.environ.get(name, default)
    if required and not val:
        raise RuntimeError(
            f"متغیر محیطی «{name}» تنظیم نشده. فایل .env رو بر اساس .env.example بساز."
        )
    return val


# ---- Discord ----
DISCORD_TOKEN = _get("DISCORD_TOKEN", required=True)
ADMIN_ROLE_NAME = _get("ADMIN_ROLE_NAME", "Admin")
GUILD_ID = _get("GUILD_ID", "") or None

# ---- Providers ----
GROQ_API_KEY = _get("GROQ_API_KEY", required=True)
CEREBRAS_API_KEY = _get("CEREBRAS_API_KEY", required=True)
MISTRAL_API_KEY = _get("MISTRAL_API_KEY", required=True)
MISTRAL_AGENT_ID = _get("MISTRAL_AGENT_ID", "")

# ---- Models ----
# توجه: llama-3.1-8b-instant و llama-3.3-70b-versatile توسط Groq در
# ۰۸/۲۰۲۶ (مرداد ۱۴۰۵) منسوخ می‌شن؛ به همین خاطر پیش‌فرض‌ها روی خانواده‌ی
# gpt-oss (که در دسته‌ی Production و پایدار Groq هست) تنظیم شدن.
GROQ_ROUTER_MODEL = _get("GROQ_ROUTER_MODEL", "openai/gpt-oss-20b")
GROQ_CHAT_MODEL = _get("GROQ_CHAT_MODEL", "openai/gpt-oss-120b")
CEREBRAS_CODE_MODEL = _get("CEREBRAS_CODE_MODEL", "zai-glm-4.7")
CEREBRAS_FAST_MODEL = _get("CEREBRAS_FAST_MODEL", "gpt-oss-120b")

# ---- Sandbox ----
SANDBOX_TIMEOUT_SECONDS = int(_get("SANDBOX_TIMEOUT_SECONDS", "25"))
SANDBOX_MAX_OUTPUT_CHARS = int(_get("SANDBOX_MAX_OUTPUT_CHARS", "1800"))

# ---- Rate limiting (به‌ازای هر کاربر، برای جلوگیری از سواستفاده/هزینه‌ی زیاد) ----
RATE_LIMIT_MAX_CALLS = int(_get("RATE_LIMIT_MAX_CALLS", "8"))
RATE_LIMIT_WINDOW_SECONDS = int(_get("RATE_LIMIT_WINDOW_SECONDS", "60"))

# ---- Files ----
OUTPUT_DIR = _get("OUTPUT_DIR", "MS")
DB_PATH = os.path.join("data", "memory.sqlite3")

# محدودیت پیام دیسکورد
DISCORD_MAX_MESSAGE = 2000
