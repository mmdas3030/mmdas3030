"""
نقطه‌ی ورود ربات. مسئول:
- ست‌آپ intents و logging
- بارگذاری همه‌ی cogها
- sync دستورات اسلش
- init دیتابیس حافظه
"""
import asyncio
import logging
import discord
from discord.ext import commands
from discord import app_commands

import config
import memory

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger("agentbot.main")

INITIAL_COGS = [
    "cogs.chat",
    "cogs.code",
    "cogs.files",
    "cogs.admin",
    "cogs.vibes",
]


async def _on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    """
    هندلر سراسری خطا برای همه‌ی دستورات اسلش (به‌جز اونایی که خودشون
    cog_app_command_error دارن، مثل AdminCog که برای MissingPermissions
    پیام اختصاصی می‌ده). این فقط برای خطاهای پیش‌بینی‌نشده‌ست چون هر دستور
    خودش داخل try/except اصلی‌ترین خطاها رو مدیریت می‌کنه.
    """
    log.exception("خطای پیش‌بینی‌نشده در دستور اسلش", exc_info=error)
    msg = f"⚠️ یه خطای غیرمنتظره پیش اومد: {error}"
    try:
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)
    except discord.HTTPException:
        pass


class AgentBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        await memory.init_db()
        self.tree.on_error = _on_app_command_error
        for ext in INITIAL_COGS:
            try:
                await self.load_extension(ext)
                log.info(f"cog بارگذاری شد: {ext}")
            except Exception:
                log.exception(f"بارگذاری cog شکست خورد: {ext}")

        if config.GUILD_ID:
            guild = discord.Object(id=int(config.GUILD_ID))
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info(f"{len(synced)} دستور اسلش روی گیلد {config.GUILD_ID} sync شد (سریع).")
        else:
            synced = await self.tree.sync()
            log.info(f"{len(synced)} دستور اسلش به‌صورت گلوبال sync شد (ممکنه تا ۱ساعت طول بکشه).")

    async def on_ready(self):
        log.info(f"وارد شدم به‌عنوان {self.user} (id: {self.user.id})")
        await self.change_presence(
            activity=discord.Activity(type=discord.ActivityType.listening, name="mention کن یا /code بزن")
        )


async def main():
    bot = AgentBot()
    async with bot:
        await bot.start(config.DISCORD_TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
