"""
حلقه‌ی ایجنت واقعی (ReAct): برخلاف router.py که فقط تصمیم می‌گیره کدوم
مدل جواب بده، این ماژول به مدل اجازه می‌ده *در طول مکالمه* خودش تصمیم
بگیره یک ابزار (فعلاً: اجرای کد پایتون در sandbox) رو صدا بزنه، نتیجه/خطا
رو ببینه، و بر اساسش ادامه بده یا خودش رو اصلاح کنه (self-correction).

جریان کار:
  1. پیام کاربر + تاریخچه به مدل داده می‌شه، همراه با تعریف ابزار sandbox.
  2. اگه مدل تصمیم بگیره ابزار رو صدا بزنه (tool_calls)، ما واقعاً کد رو
     در sandbox.py اجرا می‌کنیم و خروجی/خطا رو به‌عنوان یک پیام «tool»
     به مدل برمی‌گردونیم.
  3. مدل با دیدن نتیجه (چه موفق چه خطا) دوباره تصمیم می‌گیره: یا جواب
     نهایی رو می‌ده، یا کد رو اصلاح می‌کنه و دوباره امتحان می‌کنه.
  4. این چرخه حداکثر MAX_STEPS بار تکرار می‌شه تا از حلقه‌ی بی‌نهایت
     جلوگیری بشه.
"""
import json
import logging
import os
import re

import config
import clients.groq_client as groq_client
import clients.cerebras_client as cerebras_client
import clients.mistral_client as mistral_client
import memory
import sandbox

log = logging.getLogger("agentbot.agent")

MAX_STEPS = 15

_SAFE_NAME = re.compile(r"[^a-zA-Z0-9._-]+")

# providerهایی که chat_with_tools دارن و می‌تونیم توی حلقه‌ی ایجنت ازشون استفاده کنیم
_TOOL_CLIENTS = {
    "groq": groq_client,
    "cerebras": cerebras_client,
    "mistral": mistral_client,
}


def _safe_filename(name: str) -> str:
    name = _SAFE_NAME.sub("_", name).strip("_")
    return name or "file.txt"


def _safe_path(filename: str) -> str | None:
    """مسیر امن داخل OUTPUT_DIR رو برمی‌گردونه، یا None اگه تلاش برای خروج از اون پوشه بود."""
    safe_name = _safe_filename(filename)
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    path = os.path.abspath(os.path.join(config.OUTPUT_DIR, safe_name))
    base = os.path.abspath(config.OUTPUT_DIR) + os.sep
    return path if path.startswith(base) else None


AGENT_SYSTEM_PROMPT = (
    "تو یک دستیار هوش مصنوعیِ ایجنت‌محور هستی که می‌تونی برای رسیدن به جواب دقیق "
    "کد پایتون واقعی اجرا کنی (نه فقط حدس بزنی)، فایل واقعی بسازی/ویرایش کنی/بخونی، "
    "و در صورت نیاز تاریخچه‌ی این کانال رو جست‌وجو کنی. هر وقت سوال نیاز به محاسبه‌ی "
    "دقیق، پردازش داده، یا استدلال چندمرحله‌ای داشت، از ابزار run_python استفاده کن. "
    "هر وقت کاربر خواست یه کد بلند (مثلاً بیشتر از چند ده خط)، یه سند، یا هر محتوای "
    "دیگه رو به‌عنوان فایل واقعی (نه فقط متن توی پیام) بگیره، از ابزار write_file "
    "استفاده کن؛ این فایل مستقیم توی دیسکورد براش آپلود می‌شه، پس دیگه نیازی نیست "
    "کل محتوا رو توی پیام متنی هم تکرار کنی. اگه کاربر خواست یه فایل قبلی رو ویرایش "
    "کنه، اول با read_file محتواش رو بخون، تغییرات لازم رو اعمال کن، بعد با "
    "write_file (همون اسم فایل) دوباره ذخیره‌ش کن. برای دیدن این‌که چه فایل‌هایی از "
    "قبل ساخته شدن از list_files استفاده کن. اگه کاربر به چیزی از مکالمه‌های قبلی "
    "اشاره کرد که توی context فعلی نیست، از search_memory استفاده کن. اگه خروجی یک "
    "ابزار خطا داد، خودت خطا رو تحلیل کن، اصلاح کن و دوباره امتحان کن؛ خطای خام رو "
    "مستقیم به کاربر نده. اگه کاری که ازت خواستن چندمرحله‌ای/طولانیه (مثلاً چند "
    "فایل پشت‌سرهم یا چندبار run_python)، می‌تونی با ابزار send_message یه پیام "
    "میان‌راه بفرستی تا کاربر بدونه در حال انجامه؛ لازم نیست همه‌چیز رو تا آخر کار "
    "نگه داری. وقتی به جواب نهایی رسیدی، بدون صدا زدن ابزار، پاسخ رو به فارسی روان "
    "و مختصر بده."
)

_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "run_python",
            "description": (
                "اجرای یک قطعه کد پایتون در یک sandbox امن و برگردوندن stdout/stderr. "
                "برای محاسبات دقیق، پردازش متن/داده، یا هر جایی که حدس‌زدن ریسک خطا داره استفاده کن."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "code": {
                        "type": "string",
                        "description": "کد پایتون کامل و اجراشدنی (شامل print برای دیدن خروجی)",
                    }
                },
                "required": ["code"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_memory",
            "description": (
                "جست‌وجوی متنی در تاریخچه‌ی پیام‌های این کانال (شامل پیام‌های قدیمی‌تری "
                "که ممکنه توی context فعلی نباشن). برای پیدا کردن چیزی که کاربر قبلاً "
                "گفته یا خواسته استفاده کن."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "keyword": {
                        "type": "string",
                        "description": "کلمه یا عبارت کلیدی برای جست‌وجو",
                    }
                },
                "required": ["keyword"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": (
                "ساخت یک فایل واقعی که مستقیم توی دیسکورد آپلود می‌شه (مثلاً کد "
                "طولانی، سند، دیتای متنی/JSON و غیره). فقط توی پوشه‌ی امنِ MS "
                "ذخیره می‌شه، جای دیگه‌ای از دیسک قابل‌دسترس نیست."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                        "description": "نام فایل، مثلاً library_system.py یا notes.md",
                    },
                    "content": {
                        "type": "string",
                        "description": "محتوای کامل فایل",
                    },
                },
                "required": ["filename", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "خوندن محتوای یک فایل که قبلاً توی پوشه‌ی امنِ MS ساخته شده (برای ویرایش لازمه).",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                        "description": "اسم دقیق فایل، مثلاً library_system.py",
                    },
                },
                "required": ["filename"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "لیست فایل‌هایی که تا الان توی پوشه‌ی امنِ MS ساخته شدن.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "send_message",
            "description": (
                "فرستادن یک پیام میان‌راه به دیسکورد در حین انجام یک کار طولانی/"
                "چندمرحله‌ای، بدون این‌که منتظر بمونی کل کار تموم بشه (مثلاً "
                "«دارم فایل اول رو می‌سازم...»). این پیام جدا از جواب نهایی ارسال "
                "می‌شه، پس تکرارش نکن."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "متن پیام میان‌راه"},
                },
                "required": ["text"],
            },
        },
    },
]


async def run(
    user_text: str,
    history: list[dict],
    channel_id: int | None = None,
    model: str | None = None,
    provider: str = "groq",
    on_progress=None,
) -> tuple[str, list[str]]:
    """
    حلقه‌ی ایجنت رو اجرا می‌کنه.
    history: پیام‌های قبلی به فرمت [{"role": ..., "content": ...}, ...]
    channel_id: برای ابزار search_memory لازمه؛ اگه ندی، اون ابزار غیرفعال می‌مونه.
    provider: کدوم client برای tool-calling استفاده بشه ("groq" | "cerebras" | "mistral").
    فقط مدل‌هایی که models.py توشون supports_tools=True هست باید اینجا برسن.
    on_progress: یه تابع async اختیاری (async def f(text)) که caller می‌ده تا
    پیام‌های میان‌راه (ابزار send_message) بلافاصله توی دیسکورد فرستاده بشن، نه
    این‌که تا آخر کار نگه داشته بشن.

    خروجی: (پاسخ متنی نهایی, لیست مسیر فایل‌هایی که با write_file ساخته/ویرایش شدن).
    caller (مثلاً cogs/chat.py) باید این فایل‌ها رو به‌عنوان attachment بفرسته.
    """
    client = _TOOL_CLIENTS.get(provider, groq_client)

    messages = [{"role": "system", "content": AGENT_SYSTEM_PROMPT}] + history + [
        {"role": "user", "content": user_text}
    ]

    kwargs = {"model": model} if model else {}
    created_files: list[str] = []

    for step in range(MAX_STEPS):
        msg = await client.chat_with_tools(messages, tools=_TOOLS, **kwargs)

        tool_calls = getattr(msg, "tool_calls", None)
        if not tool_calls:
            return msg.content or "متأسفم، نتونستم جواب مشخصی تولید کنم.", created_files

        # پیام مدل (که شامل tool_calls هست) رو به تاریخچه اضافه می‌کنیم
        messages.append({
            "role": "assistant",
            "content": msg.content or "",
            "tool_calls": [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                }
                for tc in tool_calls
            ],
        })

        for tc in tool_calls:
            try:
                args = json.loads(tc.function.arguments)
            except json.JSONDecodeError:
                args = {}

            if tc.function.name == "run_python":
                code = args.get("code", "")
                log.info(f"agent step {step}: اجرای کد در sandbox")
                ok, output = await sandbox.run_python(code)
                observation = f"{'موفق' if ok else 'خطا'}:\n{output}"
            elif tc.function.name == "search_memory":
                if channel_id is None:
                    observation = "search_memory در دسترس نیست (channel_id مشخص نشده)."
                else:
                    keyword = args.get("keyword", "")
                    log.info(f"agent step {step}: جست‌وجوی حافظه برای «{keyword}»")
                    results = await memory.search_history(channel_id, keyword)
                    if not results:
                        observation = "چیزی با این کلیدواژه توی تاریخچه پیدا نشد."
                    else:
                        observation = "\n".join(f"{r['role']}: {r['content']}" for r in results)
            elif tc.function.name == "write_file":
                raw_name = args.get("filename", "")
                content = args.get("content", "")
                path = _safe_path(raw_name)
                if path is None:
                    observation = "نام فایل نامعتبره."
                else:
                    try:
                        with open(path, "w", encoding="utf-8") as f:
                            f.write(content)
                        if path not in created_files:
                            created_files.append(path)
                        log.info(f"agent step {step}: فایل ساخته/ویرایش شد -> {path}")
                        observation = f"فایل «{os.path.basename(path)}» با موفقیت ذخیره شد و برای کاربر آپلود می‌شه."
                    except OSError as e:
                        observation = f"نوشتن فایل شکست خورد: {e}"
            elif tc.function.name == "read_file":
                raw_name = args.get("filename", "")
                path = _safe_path(raw_name)
                if path is None:
                    observation = "نام فایل نامعتبره."
                elif not os.path.isfile(path):
                    observation = f"فایلی به اسم «{raw_name}» توی MS پیدا نشد."
                else:
                    try:
                        with open(path, "r", encoding="utf-8") as f:
                            observation = f.read()
                    except OSError as e:
                        observation = f"خوندن فایل شکست خورد: {e}"
            elif tc.function.name == "list_files":
                os.makedirs(config.OUTPUT_DIR, exist_ok=True)
                names = sorted(os.listdir(config.OUTPUT_DIR))
                observation = "\n".join(names) if names else "پوشه‌ی MS فعلاً خالیه."
            elif tc.function.name == "send_message":
                text = args.get("text", "")
                if on_progress and text:
                    try:
                        await on_progress(text)
                        observation = "پیام میان‌راه فرستاده شد."
                    except Exception as e:
                        observation = f"فرستادن پیام میان‌راه شکست خورد: {e}"
                else:
                    observation = "send_message در دسترس نیست، فقط توی جواب نهایی بگو."
            else:
                observation = f"ابزار ناشناخته: {tc.function.name}"

            messages.append({
                "role": "tool",
                "tool_call_id": tc.id,
                "content": observation,
            })

    # اگه بعد از MAX_STEPS هنوز جواب نهایی نداده، آخرین دیدگاه مدل رو برمی‌گردونیم
    return (
        "⚠️ ایجنت بعد از چند مرحله تلاش، نتونست به جواب قطعی برسه. لطفاً سوال رو ساده‌تر یا دقیق‌تر مطرح کن.",
        created_files,
    )
